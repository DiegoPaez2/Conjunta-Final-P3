﻿namespace WebApplication1.Models
{
    public class Pedido
    {
    }
}
