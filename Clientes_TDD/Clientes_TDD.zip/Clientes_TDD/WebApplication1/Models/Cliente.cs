﻿namespace WebApplication1.Models
{
    public class Cliente
    {
    }
}
